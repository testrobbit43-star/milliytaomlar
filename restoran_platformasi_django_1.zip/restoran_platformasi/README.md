# 🍽️ Restoran va Kafelar uchun Buyurtma Platformasi (Django)

Bu loyiha **Django** asosida yozilgan, quyidagi qismlardan iborat:

1. **Mijoz sayti** — `http://127.0.0.1:8000/` — menyu ko'rish, savatcha, buyurtma berish, buyurtmani kuzatish
2. **Admin panel** — `http://127.0.0.1:8000/admin/` — Django'ning tayyor, kod yozmasdan boshqariladigan paneli
3. **Telegram bot** — mijozlar Telegram orqali ham menyuni ko'rib, buyurtma bera oladi; yangi buyurtma tushganda restoran guruhiga avtomatik xabar boradi

Admin va mijoz qismlari **butunlay alohida manzillarda** ishlaydi (`/admin/` va `/`), bitta oynada aralashib qolish muammosi yo'q.

---

## 📦 O'rnatish (birinchi marta)

```bash
# 1. Loyiha papkasiga kiring
cd restoran_platformasi

# 2. Virtual muhit yaratish (tavsiya etiladi)
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# 3. Kerakli kutubxonalarni o'rnatish
pip install -r requirements.txt

# 4. Ma'lumotlar bazasini tayyorlash
python manage.py migrate

# 5. O'zingiz uchun admin foydalanuvchi yaratish
python manage.py createsuperuser
# (ism, email, parol so'raladi — o'zingiz kiriting)

# 6. (Ixtiyoriy) Sinov uchun demo taomlar qo'shish
python manage.py demo_malumot
```

## ▶️ Ishga tushirish

```bash
python manage.py runserver
```

- Mijoz sayti: **http://127.0.0.1:8000/**
- Admin panel: **http://127.0.0.1:8000/admin/** (5-qadamda yaratgan login/parol bilan kiring)

---

## 🤖 Telegram botni ulash

1. Telegram'da **@BotFather** ga yozing, `/newbot` buyrug'i bilan yangi bot yarating, u sizga **token** beradi.
2. Botni o'zingizning restoran guruhingizga qo'shing (yoki shaxsiy chatda ishlatasiz).
3. Guruh **Chat ID**'sini bilish uchun: guruhga bitta xabar yozing, so'ng brauzerda oching:
   `https://api.telegram.org/bot<TOKEN>/getUpdates` — javobda `"chat":{"id": -100123456789}` kabi raqamni ko'rasiz.
4. Admin panelga kiring → **⚙️ Sayt sozlamalari** → "Telegram bot ulanishi" bo'limiga token va Chat ID'ni kiriting → Saqlang.
5. Endi har safar mijoz buyurtma berganda (saytdan ham, orqadagi bot orqali ham) restoran guruhiga avtomatik xabar boradi.

### Mijozlar uchun Telegram bot (ixtiyoriy, bonus funksiya)

Mijozlar botga yozib, to'g'ridan-to'g'ri Telegram ichida ham menyuni ko'rib buyurtma bera olishlari uchun, **ikkinchi terminal oynasida** quyidagini ishga tushiring (Django sayti ham parallel ishlab turishi kerak):

```bash
python telegram_bot/bot.py
```

Bu bot xuddi shu ma'lumotlar bazasidan foydalanadi — ya'ni botdan kelgan buyurtma ham admin panelda va saytda bir xil ko'rinadi.

---

## ⚙️ Admin panel orqali NIMALARNI KOD YOZMASDAN o'zgartirish mumkin

- **⚙️ Sayt sozlamalari** — restoran nomi, logotipi, banner rasmi, ishlash vaqti, sayt rangi (5ta tayyor tema), yetkazib berish narxi, Telegram bot sozlamalari
- **🍽️ Taom turkumlari** — yangi kategoriya qo'shish, tartibini o'zgartirish, yashirish
- **🍔 Menyu taomlari** — taom qo'shish/o'chirish, narx, rasm, "tavsiya etiladi" belgisi, sotuvda bor/yo'qligi
- **🪑 Restoran stollari** — joyida ovqatlanish uchun stollar ro'yxati
- **👤 Xodimlar** — oshpaz, kuryer va boshqalarning ro'yxati
- **🙋 Mijozlar** — barcha ro'yxatdan o'tgan mijozlar
- **🧾 Buyurtmalar** — barcha buyurtmalarni ko'rish, holatini o'zgartirish (masalan "tayyorlanmoqda" → "tayyor"), har birida qaysi taomlar borligini ko'rish
- **⭐ Sharhlar** — mijozlar sharhlarini tasdiqlash/rad etish
- **🎁 Aksiyalar** — chegirma va aksiyalar qo'shish

Bularning HAMMASI faqat admin panel orqali, bironta ham kod qatori yozmasdan boshqariladi.

---

## 📂 Loyiha tuzilishi

```
restoran_platformasi/
├── manage.py
├── config/                 # Django loyiha sozlamalari
│   ├── settings.py
│   └── urls.py             # admin/ va mijoz sayti manzillari shu yerda ajratilgan
├── buyurtma/                # Asosiy ilova
│   ├── models.py            # 10 ta model: sozlamalar, turkum, taom, buyurtma va h.k.
│   ├── admin.py              # Django admin sozlamalari
│   ├── views.py              # Mijoz sayti logikasi
│   ├── urls.py
│   ├── telegram_xabar.py     # Buyurtma kelganda Telegramga xabar yuborish
│   └── templates/buyurtma/   # Mijoz saytining HTML sahifalari
├── telegram_bot/
│   └── bot.py                # Mijozlar uchun to'liq Telegram bot (aiogram)
└── requirements.txt
```

---

## 🚀 Loyihani qanday kengaytirish mumkin (40+ funksiyaga yetkazish uchun g'oyalar)

Hozirgi loyiha mustahkam **asos (fundament)** — ustiga qo'shishingiz mumkin bo'lgan g'oyalar:

- Mijoz uchun ro'yxatdan o'tish/login (Django `django.contrib.auth`)
- Onlayn to'lov integratsiyasi (Payme, Click API)
- Buyurtma tarixi va "sevimlilar" ro'yxati
- SMS orqali bildirishnoma (Eskiz.uz yoki SMS.uz API)
- Ko'p tilli sayt (o'zbek/rus/ingliz — Django `USE_I18N`)
- Kuryer uchun alohida mobil-do'st panel (masalan `/kuryer/` manzili)
- Statistika va hisobotlar (kunlik/oylik savdo grafiklari — admin panelga qo'shimcha sahifa)
- QR-kod orqali stol raqamini avtomatik aniqlash
- Push-bildirishnoma (Web Push API)

Har birini alohida-alohida, kichik qadamlar bilan so'rab qo'shdiring — shunda AI xato qilganda uni osongina aniqlab, tuzatib bo'ladi.

---

## ☁️ Render'ga joylash (deploy)

Bu loyiha **Render.com**'ga joylash uchun to'liq tayyorlangan (`render.yaml`, `build.sh`, `gunicorn`, `whitenoise`, PostgreSQL qo'llab-quvvatlashi bilan).

### Eng oson usul — `render.yaml` orqali avtomatik

1. Loyihangizni **GitHub**'ga yuklang (agar hali qilmagan bo'lsangiz: github.com'da yangi repository yarating, so'ng `git init`, `git add .`, `git commit -m "birinchi"`, `git push`).
2. **render.com**'da ro'yxatdan o'ting → "New" → **"Blueprint"** ni tanlang.
3. GitHub repositoryingizni tanlang — Render `render.yaml` faylini o'zi topib, **web servis** va **PostgreSQL bazasini** avtomatik yaratadi.
4. "Apply" tugmasini bosing — bir necha daqiqadan so'ng sayt tayyor bo'ladi.
5. Render bergan manzil orqali kiring: `https://restoran-platformasi.onrender.com/` va admin: `.../admin/`
6. Superuser yaratish uchun Render dashboard'da servisingiz ichidagi **"Shell"** bo'limini oching va yozing:
   ```bash
   python manage.py createsuperuser
   ```

### Qo'lda sozlash usuli (agar Blueprint ishlamasa)

1. Render'da **"New Web Service"** → GitHub repongizni ulang
2. **Build Command:** `./build.sh`
3. **Start Command:** `gunicorn config.wsgi:application`
4. **Environment Variables** qo'shing:
   - `SECRET_KEY` — istalgan uzun tasodifiy matn
   - `DEBUG` — `False`
   - `DATABASE_URL` — Render'da alohida "PostgreSQL" yarating, u avtomatik shu qiymatni beradi
5. Deploy qiling.

### Telegram bot haqida (Render'da)

`telegram_bot/bot.py` uzluksiz ishlashi uchun Render'da **alohida "Background Worker"** yaratish kerak (Web Service emas):
- Start Command: `python telegram_bot/bot.py`
- Bu bepul tarifda ham ishlaydi, lekin alohida servis sifatida qo'shilishi kerak.

Buyurtma tushganda Telegramga oddiy xabar yuborish funksiyasi (`telegram_xabar.py`) esa alohida sozlashning hojati yo'q — u sayt bilan birga avtomatik ishlayveradi.

### ⚠️ Rasm fayllari haqida eslatma

Render'ning bepul tarifida disk **vaqtinchalik** — har safar qayta joylanganda (deploy) yuklangan rasmlar (taom rasmlari, logotip) o'chib ketishi mumkin. Final loyiha/demo uchun bu muammo emas, lekin uzoq muddat ishlatmoqchi bo'lsangiz, kelajakda **Cloudinary** kabi bepul rasm-xostingga ulash tavsiya etiladi.

---

## ❗ Muhim eslatma (xavfsizlik)

Bu — o'quv/final loyihasi uchun mo'ljallangan. Agar uni haqiqiy internetga (production'ga) chiqarmoqchi bo'lsangiz:
- `settings.py` dagi `SECRET_KEY`ni yashiring va o'zgartiring
- `DEBUG = False` qiling
- `ALLOWED_HOSTS`ga domeningizni yozing
- Admin parolini kuchli qiling
