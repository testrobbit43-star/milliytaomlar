from django.core.management.base import BaseCommand
from buyurtma.models import Turkum, Taom, Stol, SaytSozlamalari


class Command(BaseCommand):
    help = "Sinov uchun demo ma'lumotlar (turkumlar, taomlar, stollar) qo'shadi"

    def handle(self, *args, **kwargs):
        sozlama = SaytSozlamalari.olish()
        sozlama.nomi = "Farg'ona Milliy Taomlar"
        sozlama.shior = "Farg'ona vodiysining eng mazali taomlari - endi onlayn buyurtma bilan!"
        sozlama.telefon_raqam = "+998 90 123 45 67"
        sozlama.manzil = "Farg'ona shahri, Mustaqillik ko'chasi 12"
        sozlama.save()

        milliy, _ = Turkum.objects.get_or_create(nomi="Milliy taomlar", tartib_raqami=1)
        salat, _ = Turkum.objects.get_or_create(nomi="Salatlar", tartib_raqami=2)
        ichimlik, _ = Turkum.objects.get_or_create(nomi="Ichimliklar", tartib_raqami=3)
        shirinlik, _ = Turkum.objects.get_or_create(nomi="Shirinliklar", tartib_raqami=4)

        taomlar = [
            (milliy, "Osh (Palov)", "An'anaviy Farg'ona oshi, sabzi va go'sht bilan", 28000, True),
            (milliy, "Norin", "Qo'lda tayyorlangan norin, yupqa xamir va go'sht bilan", 32000, True),
            (milliy, "Manti", "Bug'da pishirilgan manti, qatiq bilan", 25000, False),
            (milliy, "Shashlik (qo'y go'shti)", "Ko'mirda pishirilgan mazali shashlik", 18000, True),
            (milliy, "Lag'mon", "Cho'zma lag'mon, sabzavotlar bilan", 24000, False),
            (salat, "Achichuq salat", "Pomidor va piyoz salatasi", 8000, False),
            (salat, "Vitamin salat", "Yangi sabzavotlardan tayyorlangan salat", 10000, False),
            (ichimlik, "Ko'k choy", "Choynak choy", 5000, False),
            (ichimlik, "Kompot", "Uy sharoitida tayyorlangan kompot", 7000, False),
            (shirinlik, "Halva", "An'anaviy Farg'ona halvasi", 12000, False),
        ]
        for turkum, nomi, tavsif, narx, tavsiya in taomlar:
            Taom.objects.get_or_create(
                nomi=nomi,
                defaults=dict(turkum=turkum, tavsif=tavsif, narxi=narx, tavsiya_etiladi=tavsiya)
            )

        for raqam in range(1, 9):
            Stol.objects.get_or_create(raqami=raqam)

        self.stdout.write(self.style.SUCCESS("✅ Demo ma'lumotlar muvaffaqiyatli qo'shildi!"))
