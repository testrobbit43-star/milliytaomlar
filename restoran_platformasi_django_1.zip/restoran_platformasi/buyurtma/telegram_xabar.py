"""
Bu fayl Telegram botga xabar yuborish uchun javobgar.
Alohida bot dasturi ishga tushirishning HOJATI YO'Q — Django o'zi
Telegram Bot API'ga to'g'ridan-to'g'ri xabar yuboradi (requests kutubxonasi orqali).

Ishlashi uchun kerak bo'lgan narsa:
1. @BotFather orqali bot yarating, token oling.
2. Admin panelda "Sayt sozlamalari" bo'limiga token va guruh Chat ID'sini kiriting.
   (Chat ID'ni olish uchun botni guruhga qo'shing, guruhga 1 ta xabar yozing,
   so'ng https://api.telegram.org/bot<TOKEN>/getUpdates manzilini oching)
"""
import requests
from django.conf import settings


def _xabar_yuborish(matn: str):
    from .models import SaytSozlamalari
    sozlama = SaytSozlamalari.olish()

    token = sozlama.telegram_bot_token
    chat_id = sozlama.telegram_guruh_chat_id

    if not token or not chat_id:
        # Token yoki chat_id kiritilmagan — xabar yuborilmaydi, lekin xato ham chiqmaydi
        return

    url = f"https://api.telegram.org/bot{token}/sendMessage"
    try:
        requests.post(url, data={
            "chat_id": chat_id,
            "text": matn,
            "parse_mode": "HTML",
        }, timeout=5)
    except requests.RequestException as xato:
        print(f"[Telegram xabar yuborishda xatolik]: {xato}")


def yangi_buyurtma_xabari(buyurtma):
    taomlar_matni = "\n".join(
        f"  • {item.taom.nomi} — {item.soni} dona"
        for item in buyurtma.taomlar_royxati.all()
    ) or "  (taomlar hali qo'shilmagan)"

    matn = (
        f"🆕 <b>Yangi buyurtma #{buyurtma.pk}</b>\n\n"
        f"👤 Mijoz: {buyurtma.mijoz_korsatiladigan_ismi()}\n"
        f"📞 Telefon: {buyurtma.mijoz_telefon_qisqa or (buyurtma.mijoz.telefon if buyurtma.mijoz else '—')}\n"
        f"🚚 Turi: {buyurtma.get_tur_display()}\n\n"
        f"<b>Taomlar:</b>\n{taomlar_matni}\n\n"
        f"💰 Jami: {int(buyurtma.jami_summa):,} so'm".replace(",", " ")
    )
    _xabar_yuborish(matn)


def buyurtma_holati_ozgardi_xabari(buyurtma):
    matn = (
        f"🔄 <b>Buyurtma #{buyurtma.pk} holati o'zgardi</b>\n\n"
        f"Yangi holat: <b>{buyurtma.get_holat_display()}</b>\n"
        f"Mijoz: {buyurtma.mijoz_korsatiladigan_ismi()}"
    )
    _xabar_yuborish(matn)
