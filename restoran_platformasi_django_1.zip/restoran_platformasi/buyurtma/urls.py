from django.urls import path
from . import views

app_name = "buyurtma"

urlpatterns = [
    path("", views.menyu_sahifasi, name="menyu"),
    path("savatchaga-qoshish/<int:taom_id>/", views.savatchaga_qoshish, name="savatchaga_qoshish"),
    path("savatchadan-ayirish/<int:taom_id>/", views.savatchadan_ayirish, name="savatchadan_ayirish"),
    path("savatchadan-ochirish/<int:taom_id>/", views.savatchadan_ochirish, name="savatchadan_ochirish"),
    path("savatcha/", views.savatcha_sahifasi, name="savatcha"),
    path("buyurtma-berish/", views.buyurtma_berish, name="buyurtma_berish"),
    path("qabul-qilindi/<int:buyurtma_id>/", views.buyurtma_qabul_qilindi, name="buyurtma_qabul_qilindi"),
    path("kuzatish/", views.buyurtmani_kuzatish, name="kuzatish"),
    path("sharh-qoldirish/", views.sharh_qoldirish, name="sharh_qoldirish"),
]
