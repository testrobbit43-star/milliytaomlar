from django.contrib import admin
from django.utils.html import format_html
from .models import (
    SaytSozlamalari, Turkum, Taom, Stol, Xodim,
    Mijoz, Buyurtma, BuyurtmaTaomi, Sharh, Aksiya,
)

admin.site.site_header = "🍽️ Restoran Boshqaruv Paneli"
admin.site.site_title = "Restoran Admin"
admin.site.index_title = "Xush kelibsiz! Quyidan boshqarmoqchi bo'lgan bo'limni tanlang"


# ---------------------------------------------------------
# SAYT SOZLAMALARI — faqat 1 ta yozuv, o'chirib/qo'shib bo'lmaydi
# ---------------------------------------------------------
@admin.register(SaytSozlamalari)
class SaytSozlamalariAdmin(admin.ModelAdmin):
    fieldsets = (
        ("Umumiy ma'lumot", {
            "fields": ("nomi", "shior", "logotip", "banner_rasm")
        }),
        ("Aloqa ma'lumotlari", {
            "fields": ("telefon_raqam", "manzil", "ish_boshlanish_vaqti", "ish_tugash_vaqti")
        }),
        ("Ko'rinish (dizayn)", {
            "fields": ("mavzu_rangi",)
        }),
        ("Yetkazib berish", {
            "fields": ("yetkazib_berish_mavjud", "yetkazib_berish_narxi", "minimal_buyurtma_summasi")
        }),
        ("Telegram bot ulanishi", {
            "fields": ("telegram_bot_token", "telegram_guruh_chat_id"),
            "description": "Botni @BotFather orqali yarating va tokenni shu yerga kiriting."
        }),
    )

    def has_add_permission(self, request):
        return not SaytSozlamalari.objects.exists()

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(Turkum)
class TurkumAdmin(admin.ModelAdmin):
    list_display = ("nomi", "tartib_raqami", "faol")
    list_editable = ("tartib_raqami", "faol")
    search_fields = ("nomi",)


@admin.register(Taom)
class TaomAdmin(admin.ModelAdmin):
    list_display = ("rasm_korinishi", "nomi", "turkum", "narxi", "mavjud", "tavsiya_etiladi")
    list_editable = ("mavjud", "tavsiya_etiladi")
    list_filter = ("turkum", "mavjud", "tavsiya_etiladi")
    search_fields = ("nomi", "tavsif")
    list_per_page = 25

    def rasm_korinishi(self, obj):
        if obj.rasm:
            return format_html('<img src="{}" style="width:45px;height:45px;object-fit:cover;border-radius:6px;" />', obj.rasm.url)
        return "—"
    rasm_korinishi.short_description = "Rasm"


@admin.register(Stol)
class StolAdmin(admin.ModelAdmin):
    list_display = ("raqami", "izoh", "faol")
    list_editable = ("faol",)


@admin.register(Xodim)
class XodimAdmin(admin.ModelAdmin):
    list_display = ("ism_familiya", "lavozim", "telefon", "faol")
    list_filter = ("lavozim", "faol")
    search_fields = ("ism_familiya", "telefon")


@admin.register(Mijoz)
class MijozAdmin(admin.ModelAdmin):
    list_display = ("ism", "telefon", "manzil", "royxatdan_otgan_vaqt")
    search_fields = ("ism", "telefon")
    readonly_fields = ("royxatdan_otgan_vaqt",)


class BuyurtmaTaomiInline(admin.TabularInline):
    model = BuyurtmaTaomi
    extra = 1
    autocomplete_fields = ["taom"]


@admin.register(Buyurtma)
class BuyurtmaAdmin(admin.ModelAdmin):
    list_display = ("id", "mijoz_korsatiladigan_ismi", "tur", "holat", "jami_summa",
                    "telegram_orqali", "yaratilgan_vaqt")
    list_filter = ("holat", "tur", "telegram_orqali", "yaratilgan_vaqt")
    list_editable = ("holat",)
    search_fields = ("mijoz__ism", "mijoz_ismi_qisqa", "mijoz_telefon_qisqa", "id")
    inlines = [BuyurtmaTaomiInline]
    readonly_fields = ("yaratilgan_vaqt", "yangilangan_vaqt", "telegram_orqali")
    date_hierarchy = "yaratilgan_vaqt"

    fieldsets = (
        ("Mijoz haqida", {
            "fields": ("mijoz", "mijoz_ismi_qisqa", "mijoz_telefon_qisqa")
        }),
        ("Buyurtma tafsilotlari", {
            "fields": ("tur", "stol", "yetkazib_berish_manzili", "izoh")
        }),
        ("Holat va to'lov", {
            "fields": ("holat", "tolov_turi", "jami_summa", "yetkazib_berish_narxi", "biriktirilgan_xodim")
        }),
        ("Texnik ma'lumot", {
            "fields": ("telegram_orqali", "yaratilgan_vaqt", "yangilangan_vaqt")
        }),
    )

    def save_model(self, request, obj, form, change):
        eski_holat = None
        if change:
            eski_holat = Buyurtma.objects.get(pk=obj.pk).holat
        super().save_model(request, obj, form, change)
        if eski_holat != obj.holat:
            from .telegram_xabar import buyurtma_holati_ozgardi_xabari
            buyurtma_holati_ozgardi_xabari(obj)


@admin.register(Sharh)
class SharhAdmin(admin.ModelAdmin):
    list_display = ("mijoz_ismi", "baho", "tasdiqlangan", "yaratilgan_vaqt")
    list_editable = ("tasdiqlangan",)
    list_filter = ("baho", "tasdiqlangan")


@admin.register(Aksiya)
class AksiyaAdmin(admin.ModelAdmin):
    list_display = ("sarlavha", "chegirma_foizi", "boshlanish_sanasi", "tugash_sanasi", "faol")
    list_editable = ("faol",)
    list_filter = ("faol",)
