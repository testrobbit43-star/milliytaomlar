from decimal import Decimal

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.views.decorators.http import require_POST

from .models import (
    SaytSozlamalari, Turkum, Taom, Buyurtma, BuyurtmaTaomi,
    Mijoz, Sharh, Aksiya,
)
from .telegram_xabar import yangi_buyurtma_xabari

SAVATCHA_SESSION_KALITI = "savatcha"


def _savatchani_olish(request):
    return request.session.get(SAVATCHA_SESSION_KALITI, {})


def _savatchani_saqlash(request, savatcha):
    request.session[SAVATCHA_SESSION_KALITI] = savatcha
    request.session.modified = True


def _savatcha_tafsilotlari(request):
    savatcha = _savatchani_olish(request)
    tafsilotlar = []
    jami_summa = Decimal(0)
    for taom_id, soni in savatcha.items():
        try:
            taom = Taom.objects.get(pk=taom_id, mavjud=True)
        except Taom.DoesNotExist:
            continue
        qator_summasi = taom.narxi * soni
        jami_summa += qator_summasi
        tafsilotlar.append({"taom": taom, "soni": soni, "qator_summasi": qator_summasi})
    return tafsilotlar, jami_summa


def menyu_sahifasi(request):
    sozlama = SaytSozlamalari.olish()
    turkumlar = Turkum.objects.filter(faol=True).prefetch_related("taomlar")
    tavsiya_etilganlar = Taom.objects.filter(tavsiya_etiladi=True, mavjud=True)[:6]
    aksiyalar = Aksiya.objects.filter(faol=True)
    savatcha = _savatchani_olish(request)
    savatchadagi_dona = sum(savatcha.values())

    return render(request, "buyurtma/menyu.html", {
        "sozlama": sozlama,
        "turkumlar": turkumlar,
        "tavsiya_etilganlar": tavsiya_etilganlar,
        "aksiyalar": aksiyalar,
        "savatchadagi_dona": savatchadagi_dona,
    })


@require_POST
def savatchaga_qoshish(request, taom_id):
    taom = get_object_or_404(Taom, pk=taom_id, mavjud=True)
    savatcha = _savatchani_olish(request)
    kalit = str(taom.pk)
    savatcha[kalit] = savatcha.get(kalit, 0) + 1
    _savatchani_saqlash(request, savatcha)
    messages.success(request, f"'{taom.nomi}' savatchaga qo'shildi.")
    return redirect(request.META.get("HTTP_REFERER", "buyurtma:menyu"))


@require_POST
def savatchadan_ayirish(request, taom_id):
    savatcha = _savatchani_olish(request)
    kalit = str(taom_id)
    if kalit in savatcha:
        savatcha[kalit] -= 1
        if savatcha[kalit] <= 0:
            del savatcha[kalit]
        _savatchani_saqlash(request, savatcha)
    return redirect("buyurtma:savatcha")


@require_POST
def savatchadan_ochirish(request, taom_id):
    savatcha = _savatchani_olish(request)
    kalit = str(taom_id)
    if kalit in savatcha:
        del savatcha[kalit]
        _savatchani_saqlash(request, savatcha)
    return redirect("buyurtma:savatcha")


def savatcha_sahifasi(request):
    sozlama = SaytSozlamalari.olish()
    tafsilotlar, jami_summa = _savatcha_tafsilotlari(request)
    return render(request, "buyurtma/savatcha.html", {
        "sozlama": sozlama, "tafsilotlar": tafsilotlar, "jami_summa": jami_summa,
    })


def buyurtma_berish(request):
    sozlama = SaytSozlamalari.olish()
    tafsilotlar, jami_summa = _savatcha_tafsilotlari(request)

    if not tafsilotlar:
        messages.warning(request, "Savatchangiz bo'sh. Avval taom tanlang.")
        return redirect("buyurtma:menyu")

    if request.method == "POST":
        ism = request.POST.get("ism", "").strip()
        telefon = request.POST.get("telefon", "").strip()
        tur = request.POST.get("tur", "olib_ketish")
        manzil = request.POST.get("manzil", "").strip()
        izoh = request.POST.get("izoh", "").strip()

        if not ism or not telefon:
            messages.error(request, "Ism va telefon raqamni kiritish shart.")
            return redirect("buyurtma:buyurtma_berish")

        mijoz, _ = Mijoz.objects.get_or_create(
            telefon=telefon, defaults={"ism": ism, "manzil": manzil}
        )

        yetkazib_berish_narxi = sozlama.yetkazib_berish_narxi if tur == "yetkazib_berish" else 0

        yangi_buyurtma = Buyurtma.objects.create(
            mijoz=mijoz, mijoz_ismi_qisqa=ism, mijoz_telefon_qisqa=telefon,
            tur=tur, yetkazib_berish_manzili=manzil, izoh=izoh,
            yetkazib_berish_narxi=yetkazib_berish_narxi,
        )

        for item in tafsilotlar:
            BuyurtmaTaomi.objects.create(
                buyurtma=yangi_buyurtma, taom=item["taom"], soni=item["soni"],
                narxi_buyurtma_vaqtida=item["taom"].narxi,
            )

        yangi_buyurtma.hisoblash()
        yangi_buyurtma_xabari(yangi_buyurtma)

        _savatchani_saqlash(request, {})
        request.session["oxirgi_buyurtma_id"] = yangi_buyurtma.pk

        return redirect("buyurtma:buyurtma_qabul_qilindi", buyurtma_id=yangi_buyurtma.pk)

    return render(request, "buyurtma/buyurtma_berish.html", {
        "sozlama": sozlama, "tafsilotlar": tafsilotlar, "jami_summa": jami_summa,
    })


def buyurtma_qabul_qilindi(request, buyurtma_id):
    sozlama = SaytSozlamalari.olish()
    buyurtma = get_object_or_404(Buyurtma, pk=buyurtma_id)
    return render(request, "buyurtma/qabul_qilindi.html", {"sozlama": sozlama, "buyurtma": buyurtma})


def buyurtmani_kuzatish(request):
    sozlama = SaytSozlamalari.olish()
    buyurtmalar = None
    telefon = request.GET.get("telefon", "").strip()
    if telefon:
        buyurtmalar = Buyurtma.objects.filter(
            mijoz_telefon_qisqa=telefon
        ).order_by("-yaratilgan_vaqt")[:10]

    return render(request, "buyurtma/kuzatish.html", {
        "sozlama": sozlama, "buyurtmalar": buyurtmalar, "telefon": telefon,
    })


@require_POST
def sharh_qoldirish(request):
    ism = request.POST.get("ism", "").strip()
    baho = request.POST.get("baho", 5)
    matn = request.POST.get("matn", "").strip()
    if ism:
        Sharh.objects.create(mijoz_ismi=ism, baho=baho, matn=matn)
        messages.success(request, "Sharhingiz uchun rahmat! Moderatordan o'tgach saytda ko'rinadi.")
    return redirect("buyurtma:menyu")
