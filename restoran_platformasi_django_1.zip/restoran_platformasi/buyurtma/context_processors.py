from .models import SaytSozlamalari


def sayt_sozlamalari(request):
    """
    Bu funksiya har bir sahifada 'global_sozlama' nomi bilan
    sayt sozlamalarini (nomi, rangi, logotipi va h.k.) mavjud qiladi.
    Shu tufayli admin panelda o'zgartirilgan narsalar KOD YOZMASDAN
    darhol butun saytda ko'rinadi.
    """
    return {"global_sozlama": SaytSozlamalari.olish()}
