from django.db import models


# =========================================================
# 1. SAYT SOZLAMALARI (Admin bu yerdan KOD YOZMASDAN
#    mijoz saytining nomi, rangi, logotipi, Telegram bot
#    tokeni va boshqa hamma narsani o'zgartira oladi)
# =========================================================
class SaytSozlamalari(models.Model):
    THEME_TANLOVLARI = [
        ("amber", "Amber (Sariq-to'q sariq)"),
        ("emerald", "Emerald (Yashil)"),
        ("blue", "Ko'k"),
        ("rose", "Pushti-qizil"),
        ("indigo", "Indigo (Binafsha-ko'k)"),
    ]

    nomi = models.CharField("Restoran nomi", max_length=150, default="Mening Restoranim")
    shior = models.CharField("Bannerdagi qisqa shior", max_length=200, blank=True,
                              help_text="Masalan: 'Farg'ona vodiysining eng mazali taomlari'")
    logotip = models.ImageField("Logotip", upload_to="sozlamalar/", blank=True, null=True)
    banner_rasm = models.ImageField("Bosh sahifa banneri", upload_to="sozlamalar/", blank=True, null=True)

    telefon_raqam = models.CharField("Telefon raqami", max_length=20, blank=True)
    manzil = models.CharField("Manzil", max_length=255, blank=True)

    ish_boshlanish_vaqti = models.TimeField("Ish boshlanish vaqti", default="08:00")
    ish_tugash_vaqti = models.TimeField("Ish tugash vaqti", default="23:00")

    mavzu_rangi = models.CharField("Sayt rangi (tema)", max_length=20,
                                    choices=THEME_TANLOVLARI, default="amber")

    yetkazib_berish_mavjud = models.BooleanField("Yetkazib berish xizmati bormi?", default=True)
    yetkazib_berish_narxi = models.DecimalField("Yetkazib berish narxi (so'm)", max_digits=10,
                                                 decimal_places=0, default=15000)
    minimal_buyurtma_summasi = models.DecimalField("Minimal buyurtma summasi (so'm)", max_digits=10,
                                                    decimal_places=0, default=0)

    telegram_bot_token = models.CharField(
        "Telegram bot tokeni", max_length=255, blank=True,
        help_text="@BotFather orqali olingan token. Masalan: 123456:ABC-DEF..."
    )
    telegram_guruh_chat_id = models.CharField(
        "Telegram guruh/kanal Chat ID", max_length=100, blank=True,
        help_text="Yangi buyurtmalar shu guruhga xabar sifatida yuboriladi"
    )

    def save(self, *args, **kwargs):
        self.pk = 1
        super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        pass

    @classmethod
    def olish(cls):
        obj, _ = cls.objects.get_or_create(pk=1)
        return obj

    def __str__(self):
        return f"Sayt sozlamalari — {self.nomi}"

    class Meta:
        verbose_name = "Sayt sozlamasi"
        verbose_name_plural = "⚙️ Sayt sozlamalari"


# =========================================================
# 2. TAOM TURKUMLARI (Kategoriyalar)
# =========================================================
class Turkum(models.Model):
    nomi = models.CharField("Turkum nomi", max_length=100)
    tartib_raqami = models.PositiveIntegerField("Tartib raqami", default=0)
    faol = models.BooleanField("Faolmi (saytda ko'rinsinmi)?", default=True)

    class Meta:
        verbose_name = "Taom turkumi"
        verbose_name_plural = "🍽️ Taom turkumlari"
        ordering = ["tartib_raqami", "nomi"]

    def __str__(self):
        return self.nomi


# =========================================================
# 3. MENYU TAOMLARI
# =========================================================
class Taom(models.Model):
    turkum = models.ForeignKey(Turkum, on_delete=models.CASCADE, related_name="taomlar",
                                verbose_name="Turkumi")
    nomi = models.CharField("Taom nomi", max_length=150)
    tavsif = models.TextField("Tavsifi", blank=True)
    narxi = models.DecimalField("Narxi (so'm)", max_digits=10, decimal_places=0)
    rasm = models.ImageField("Rasm", upload_to="taomlar/", blank=True, null=True)

    mavjud = models.BooleanField("Sotuvda bormi?", default=True)
    tavsiya_etiladi = models.BooleanField("Tavsiya etiladigan taom", default=False)
    tayyorlanish_vaqti_daq = models.PositiveIntegerField("Taxminiy tayyorlanish vaqti (daqiqa)", default=15)

    yaratilgan_vaqt = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Taom"
        verbose_name_plural = "🍔 Menyu taomlari"
        ordering = ["turkum__tartib_raqami", "nomi"]

    def __str__(self):
        return f"{self.nomi} — {self.narxi} so'm"


# =========================================================
# 4. RESTORANDAGI STOLLAR
# =========================================================
class Stol(models.Model):
    raqami = models.PositiveIntegerField("Stol raqami", unique=True)
    izoh = models.CharField("Izoh", max_length=100, blank=True)
    faol = models.BooleanField("Faolmi?", default=True)

    class Meta:
        verbose_name = "Stol"
        verbose_name_plural = "🪑 Restoran stollari"
        ordering = ["raqami"]

    def __str__(self):
        return f"Stol №{self.raqami}"


# =========================================================
# 5. XODIMLAR
# =========================================================
class Xodim(models.Model):
    LAVOZIM_TANLOVLARI = [
        ("oshpaz", "Oshpaz"),
        ("kuryer", "Kuryer"),
        ("ofitsiant", "Ofitsiant"),
        ("boshqaruvchi", "Boshqaruvchi"),
    ]
    ism_familiya = models.CharField("Ism familiya", max_length=150)
    lavozim = models.CharField("Lavozimi", max_length=20, choices=LAVOZIM_TANLOVLARI)
    telefon = models.CharField("Telefon raqami", max_length=20, blank=True)
    telegram_id = models.CharField("Telegram ID (bildirishnoma uchun)", max_length=50, blank=True)
    faol = models.BooleanField("Ishlamoqdami?", default=True)

    class Meta:
        verbose_name = "Xodim"
        verbose_name_plural = "👤 Xodimlar"

    def __str__(self):
        return f"{self.ism_familiya} ({self.get_lavozim_display()})"


# =========================================================
# 6. MIJOZLAR
# =========================================================
class Mijoz(models.Model):
    ism = models.CharField("Ismi", max_length=100)
    telefon = models.CharField("Telefon raqami", max_length=20)
    manzil = models.CharField("Doimiy manzili", max_length=255, blank=True)
    telegram_id = models.CharField("Telegram ID", max_length=50, blank=True, null=True)
    royxatdan_otgan_vaqt = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Mijoz"
        verbose_name_plural = "🙋 Mijozlar"

    def __str__(self):
        return f"{self.ism} ({self.telefon})"


# =========================================================
# 7. BUYURTMA
# =========================================================
class Buyurtma(models.Model):
    HOLAT_TANLOVLARI = [
        ("yangi", "🆕 Yangi buyurtma"),
        ("qabul_qilindi", "✅ Qabul qilindi"),
        ("tayyorlanmoqda", "👨‍🍳 Tayyorlanmoqda"),
        ("tayyor", "📦 Tayyor"),
        ("yolda", "🛵 Yetkazilmoqda"),
        ("yakunlandi", "🎉 Yakunlandi"),
        ("bekor_qilindi", "❌ Bekor qilindi"),
    ]
    TUR_TANLOVLARI = [
        ("olib_ketish", "Olib ketish"),
        ("yetkazib_berish", "Yetkazib berish"),
        ("joyida", "Restoranda ovqatlanish"),
    ]
    TOLOV_TANLOVLARI = [
        ("naqd", "Naqd pul"),
        ("karta", "Bank kartasi (yetkazib berilganda)"),
        ("onlayn", "Onlayn to'lov"),
    ]

    mijoz = models.ForeignKey(Mijoz, on_delete=models.SET_NULL, null=True, blank=True,
                               related_name="buyurtmalar", verbose_name="Mijoz")
    mijoz_ismi_qisqa = models.CharField("Mijoz ismi (agar ro'yxatdan o'tmagan bo'lsa)",
                                         max_length=100, blank=True)
    mijoz_telefon_qisqa = models.CharField("Mijoz telefoni", max_length=20, blank=True)

    tur = models.CharField("Buyurtma turi", max_length=20, choices=TUR_TANLOVLARI, default="olib_ketish")
    stol = models.ForeignKey(Stol, on_delete=models.SET_NULL, null=True, blank=True,
                              verbose_name="Stol (joyida bo'lsa)")
    yetkazib_berish_manzili = models.CharField("Yetkazib berish manzili", max_length=255, blank=True)

    holat = models.CharField("Buyurtma holati", max_length=20, choices=HOLAT_TANLOVLARI, default="yangi")
    tolov_turi = models.CharField("To'lov turi", max_length=20, choices=TOLOV_TANLOVLARI, default="naqd")

    izoh = models.TextField("Mijoz izohi", blank=True)

    jami_summa = models.DecimalField("Jami summa (so'm)", max_digits=12, decimal_places=0, default=0)
    yetkazib_berish_narxi = models.DecimalField("Yetkazib berish narxi (so'm)", max_digits=10,
                                                 decimal_places=0, default=0)

    biriktirilgan_xodim = models.ForeignKey(Xodim, on_delete=models.SET_NULL, null=True, blank=True,
                                             verbose_name="Mas'ul xodim")

    telegram_orqali = models.BooleanField("Telegram bot orqali berilganmi?", default=False)

    yaratilgan_vaqt = models.DateTimeField("Buyurtma vaqti", auto_now_add=True)
    yangilangan_vaqt = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Buyurtma"
        verbose_name_plural = "🧾 Buyurtmalar"
        ordering = ["-yaratilgan_vaqt"]

    def __str__(self):
        return f"Buyurtma #{self.pk} — {self.get_holat_display()}"

    def mijoz_korsatiladigan_ismi(self):
        if self.mijoz:
            return self.mijoz.ism
        return self.mijoz_ismi_qisqa or "Noma'lum mijoz"

    def hisoblash(self):
        jami = sum(item.qatordagi_summa() for item in self.taomlar_royxati.all())
        self.jami_summa = jami + (self.yetkazib_berish_narxi or 0)
        self.save(update_fields=["jami_summa"])


# =========================================================
# 8. BUYURTMADAGI HAR BIR TAOM
# =========================================================
class BuyurtmaTaomi(models.Model):
    buyurtma = models.ForeignKey(Buyurtma, on_delete=models.CASCADE, related_name="taomlar_royxati",
                                  verbose_name="Buyurtma")
    taom = models.ForeignKey(Taom, on_delete=models.PROTECT, verbose_name="Taom")
    soni = models.PositiveIntegerField("Soni", default=1)
    narxi_buyurtma_vaqtida = models.DecimalField("Narxi (buyurtma berilgan vaqtdagi)", max_digits=10,
                                                  decimal_places=0)

    class Meta:
        verbose_name = "Buyurtmadagi taom"
        verbose_name_plural = "🍽️ Buyurtmadagi taomlar"

    def qatordagi_summa(self):
        return self.soni * self.narxi_buyurtma_vaqtida

    def save(self, *args, **kwargs):
        if not self.narxi_buyurtma_vaqtida:
            self.narxi_buyurtma_vaqtida = self.taom.narxi
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.taom.nomi} x{self.soni}"


# =========================================================
# 9. SHARHLAR / BAHOLAR
# =========================================================
class Sharh(models.Model):
    mijoz_ismi = models.CharField("Mijoz ismi", max_length=100)
    buyurtma = models.ForeignKey(Buyurtma, on_delete=models.SET_NULL, null=True, blank=True,
                                  verbose_name="Bog'liq buyurtma")
    baho = models.PositiveSmallIntegerField("Baho (1-5 yulduz)", default=5)
    matn = models.TextField("Sharh matni", blank=True)
    tasdiqlangan = models.BooleanField("Saytda ko'rsatishga ruxsat berilganmi?", default=False)
    yaratilgan_vaqt = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Sharh"
        verbose_name_plural = "⭐ Mijozlar sharhlari"
        ordering = ["-yaratilgan_vaqt"]

    def __str__(self):
        return f"{self.mijoz_ismi} — {self.baho}★"


# =========================================================
# 10. AKSIYALAR / CHEGIRMALAR
# =========================================================
class Aksiya(models.Model):
    sarlavha = models.CharField("Aksiya sarlavhasi", max_length=150)
    tavsif = models.TextField("Tavsifi", blank=True)
    rasm = models.ImageField("Rasm (banner)", upload_to="aksiyalar/", blank=True, null=True)
    chegirma_foizi = models.PositiveSmallIntegerField("Chegirma foizi (%)", default=0)
    boshlanish_sanasi = models.DateField("Boshlanish sanasi")
    tugash_sanasi = models.DateField("Tugash sanasi")
    faol = models.BooleanField("Faolmi?", default=True)

    class Meta:
        verbose_name = "Aksiya"
        verbose_name_plural = "🎁 Aksiyalar va chegirmalar"

    def __str__(self):
        return self.sarlavha
