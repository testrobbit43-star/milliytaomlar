"""
MIJOZLAR UCHUN TELEGRAM BOT
============================
Bu alohida dastur — Django saytidan mustaqil ishga tushiriladi, lekin
xuddi shu ma'lumotlar bazasidan (SQLite) foydalanadi. Ya'ni mijoz botdan
buyurtma bersa, u ham Django admin panelda ko'rinadi va sayt bilan bir xil
ma'lumotlar bazasiga yoziladi.

ISHGA TUSHIRISH:
1. requirements.txt dagi kutubxonalarni o'rnating:
     pip install aiogram
2. Admin panelda (Sayt sozlamalari) Telegram bot tokenini kiritganingizga
   ishonch hosil qiling (yoki pastdagi BOT_TOKEN qatoriga to'g'ridan-to'g'ri yozing).
3. Terminalda ishga tushiring:
     python telegram_bot/bot.py

ESLATMA: Bu bot va Django sayti IKKALASI HAM bir vaqtda ishlab turishi kerak
(ikkita alohida terminal oynasida: biri `python manage.py runserver`,
ikkinchisi `python telegram_bot/bot.py`).
"""
import os
import sys
import django
import asyncio

# --- Django muhitini ulash (Django modellaridan foydalanish uchun) ---
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")
django.setup()

from aiogram import Bot, Dispatcher, F
from aiogram.filters import CommandStart
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage

from asgiref.sync import sync_to_async
from buyurtma.models import SaytSozlamalari, Turkum, Taom, Buyurtma, BuyurtmaTaomi, Mijoz


# ---------------------------------------------------------
# Holatlar (foydalanuvchi buyurtma berish jarayonida qaysi bosqichda ekanini bilish uchun)
# ---------------------------------------------------------
class BuyurtmaHolati(StatesGroup):
    ism_kutilmoqda = State()
    telefon_kutilmoqda = State()


# Har bir foydalanuvchining vaqtinchalik savatchasi (xotirada, oddiy misol uchun)
foydalanuvchi_savatchalari = {}


@sync_to_async
def sozlamani_olish():
    return SaytSozlamalari.olish()


@sync_to_async
def bot_tokenini_olish():
    return SaytSozlamalari.olish().telegram_bot_token


@sync_to_async
def turkumlarni_olish():
    return list(Turkum.objects.filter(faol=True))


@sync_to_async
def taomlarni_olish(turkum_id):
    return list(Taom.objects.filter(turkum_id=turkum_id, mavjud=True))


@sync_to_async
def taomni_olish(taom_id):
    return Taom.objects.get(pk=taom_id)


@sync_to_async
def buyurtma_yaratish(telegram_id, ism, telefon, savatcha):
    mijoz, _ = Mijoz.objects.get_or_create(
        telegram_id=str(telegram_id),
        defaults={"ism": ism, "telefon": telefon}
    )
    yangi = Buyurtma.objects.create(
        mijoz=mijoz, mijoz_ismi_qisqa=ism, mijoz_telefon_qisqa=telefon,
        tur="olib_ketish", telegram_orqali=True,
    )
    for taom_id, soni in savatcha.items():
        taom = Taom.objects.get(pk=taom_id)
        BuyurtmaTaomi.objects.create(
            buyurtma=yangi, taom=taom, soni=soni, narxi_buyurtma_vaqtida=taom.narxi
        )
    yangi.hisoblash()
    return yangi


dp = Dispatcher(storage=MemoryStorage())


@dp.message(CommandStart())
async def start_komandasi(message: Message):
    sozlama = await sozlamani_olish()
    turkumlar = await turkumlarni_olish()

    tugmalar = [
        [InlineKeyboardButton(text=f"🍽️ {t.nomi}", callback_data=f"turkum:{t.id}")]
        for t in turkumlar
    ]
    tugmalar.append([InlineKeyboardButton(text="🛒 Savatcham", callback_data="savatcha")])

    await message.answer(
        f"Assalomu alaykum! <b>{sozlama.nomi}</b> botiga xush kelibsiz!\n\n"
        f"{sozlama.shior}\n\nQuyidan taom turkumini tanlang:",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=tugmalar),
        parse_mode="HTML",
    )


@dp.callback_query(F.data.startswith("turkum:"))
async def turkum_tanlandi(callback: CallbackQuery):
    turkum_id = int(callback.data.split(":")[1])
    taomlar = await taomlarni_olish(turkum_id)

    if not taomlar:
        await callback.answer("Bu turkumda hozircha taom yo'q.", show_alert=True)
        return

    tugmalar = [
        [InlineKeyboardButton(text=f"{t.nomi} — {int(t.narxi):,} so'm".replace(",", " "),
                               callback_data=f"qoshish:{t.id}")]
        for t in taomlar
    ]
    tugmalar.append([InlineKeyboardButton(text="⬅️ Orqaga", callback_data="orqaga")])

    await callback.message.edit_text(
        "Taom tanlang (bosilganda savatchaga qo'shiladi):",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=tugmalar),
    )


@dp.callback_query(F.data.startswith("qoshish:"))
async def taom_qoshish(callback: CallbackQuery):
    taom_id = int(callback.data.split(":")[1])
    taom = await taomni_olish(taom_id)

    kalit = callback.from_user.id
    savat = foydalanuvchi_savatchalari.setdefault(kalit, {})
    savat[taom_id] = savat.get(taom_id, 0) + 1

    await callback.answer(f"'{taom.nomi}' savatchaga qo'shildi ✅")


@dp.callback_query(F.data == "savatcha")
async def savatchani_korsatish(callback: CallbackQuery):
    kalit = callback.from_user.id
    savat = foydalanuvchi_savatchalari.get(kalit, {})

    if not savat:
        await callback.answer("Savatchangiz bo'sh.", show_alert=True)
        return

    matn_qatorlari = []
    jami = 0
    for taom_id, soni in savat.items():
        taom = await taomni_olish(taom_id)
        summasi = int(taom.narxi) * soni
        jami += summasi
        matn_qatorlari.append(f"• {taom.nomi} x{soni} — {summasi:,} so'm".replace(",", " "))

    matn = "\n".join(matn_qatorlari) + f"\n\n<b>Jami: {jami:,} so'm</b>".replace(",", " ")

    tugmalar = [[InlineKeyboardButton(text="✅ Buyurtmani tasdiqlash", callback_data="tasdiqlash")]]
    await callback.message.answer(matn, reply_markup=InlineKeyboardMarkup(inline_keyboard=tugmalar),
                                   parse_mode="HTML")


@dp.callback_query(F.data == "tasdiqlash")
async def tasdiqlashni_boshlash(callback: CallbackQuery, state: FSMContext):
    await callback.message.answer("Ismingizni kiriting:")
    await state.set_state(BuyurtmaHolati.ism_kutilmoqda)


@dp.message(BuyurtmaHolati.ism_kutilmoqda)
async def ism_qabul_qilindi(message: Message, state: FSMContext):
    await state.update_data(ism=message.text)
    await message.answer("Telefon raqamingizni kiriting (masalan: +998901234567):")
    await state.set_state(BuyurtmaHolati.telefon_kutilmoqda)


@dp.message(BuyurtmaHolati.telefon_kutilmoqda)
async def telefon_qabul_qilindi(message: Message, state: FSMContext):
    malumot = await state.get_data()
    ism = malumot["ism"]
    telefon = message.text

    savat = foydalanuvchi_savatchalari.get(message.from_user.id, {})
    if not savat:
        await message.answer("Savatchangiz bo'sh, buyurtma yaratilmadi.")
        await state.clear()
        return

    buyurtma = await buyurtma_yaratish(message.from_user.id, ism, telefon, savat)
    foydalanuvchi_savatchalari[message.from_user.id] = {}
    await state.clear()

    await message.answer(
        f"🎉 Buyurtmangiz qabul qilindi!\nBuyurtma raqami: #{buyurtma.id}\n"
        f"Jami: {int(buyurtma.jami_summa):,} so'm".replace(",", " ") +
        "\n\nTayyor bo'lganda sizga xabar beramiz. Rahmat!"
    )


@dp.callback_query(F.data == "orqaga")
async def orqaga_qaytish(callback: CallbackQuery):
    await start_komandasi(callback.message)


async def asosiy():
    token = await bot_tokenini_olish()
    if not token:
        print("❌ XATOLIK: Telegram bot tokeni admin panelda kiritilmagan!")
        print("Admin panel → Sayt sozlamalari → Telegram bot tokeni maydoniga tokeningizni kiriting.")
        return

    bot = Bot(token=token)
    print("✅ Bot ishga tushdi. To'xtatish uchun CTRL+C bosing.")
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(asosiy())
