#!/usr/bin/env bash
# Render bu skriptni har safar deploy qilinganda avtomatik ishga tushiradi.
set -o errexit

pip install -r requirements.txt

python manage.py collectstatic --no-input
python manage.py migrate
